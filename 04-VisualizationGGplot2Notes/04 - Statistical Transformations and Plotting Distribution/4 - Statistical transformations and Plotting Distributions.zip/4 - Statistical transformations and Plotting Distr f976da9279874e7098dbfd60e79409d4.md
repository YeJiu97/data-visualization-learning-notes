# 4 - Statistical transformations and Plotting Distributions

## 统计变换

统计变换是一种基于原始数据计算出新的变量的方法。统计变换通常用于满足数据分析的要求，例如对数据进行正态化或对数据进行归一化。常见的统计变换包括对数变换，平方根变换，倒数变换，z-score标准化等。

在R语言中，可以使用不同的函数来进行统计变换。例如，使用`log()`函数进行对数变换，使用`sqrt()`函数进行平方根变换，使用`1/x`进行倒数变换，使用`scale()`函数进行z-score标准化等。

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled.png)

ggplot中的每一层都有一个统计变换。

有时候我们想要按照“原样”来绘制数据：

```
library(tidyverse)

ggplot(mpg) + geom_point(aes(x = class, y = hwy))
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%201.png)

但是有时候我们想要绘制数据的转换图：

```
ggplot(mpg) + geom_smooth(aes(x = displ, y = hwy))
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%202.png)

这就是一次统计转换，因为原始数据并不能够直接得到这样的一个结果，而是通过一定的统计转换之后，在按照统计转换的结果来进行绘图。

连个部分：

1. geoms：控制the way the plot looks
2. stats：control the way data is transformed

每一个geometry都有一个default stat：

1. geom_line：default stat is stat_identity
2. geom_point：default stat is stat_identity
3. geom_smooth：default stat is stat_smooth

我们可以来看这样的两段代码：

```
ggplot(mpg, aes(x = cty, y = hwy)) + geom_point(stat = "identity")
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%203.png)

另一段代码：

```
ggplot(mpg, aes(x = cty, y = hwy)) + geom_point(stat = "smooth")
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%204.png)

然后查看一下smooth：

```
ggplot(mpg, aes(x = cty, y = hwy)) + geom_smooth(stat = "identity")
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%205.png)

geometry都有default stat，但是是可以被改变的。

每一个geometry都有default geom：

1. stat_smooth：default geom is geom_smooth
2. stat_count：default geom is geom_bar
3. stat_sum：default geom is geom_point

我们可以看这样的例子：

```
ggplot(mpg, aes(x = cty)) + stat_count()
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%206.png)

```
ggplot(mpg, aes(x = cty)) + geom_bar()
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%207.png)

可以发现这两张图是一样的，这就意味着geo_bar()和stat_count()其实是一回事。

## 有趣的stats

```
ggplot(mpg, aes(x = cty, y = hwy)) + geom_point()
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%208.png)

```
ggplot(mpg, aes(x = cty, y = hwy)) +
  geom_point() + geom_smooth()
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%209.png)

```
> head(0xboys)
Error: unexpected symbol in "head(0xboys"
> head(Oxboys)
Grouped Data: height ~ age | Subject
  Subject     age height Occasion
1       1 -1.0000  140.5        1
2       1 -0.7479  143.4        2
3       1 -0.4630  144.8        3
4       1 -0.1643  147.1        4
5       1 -0.0027  147.7        5
6       1  0.2466  150.2        6
```

开始绘制：

```
ggplot(Oxboys, aes(x = age, y = height)) + geom_line()
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2010.png)

```
ggplot(Oxboys, aes(x = age, y = height, group = Subject)) + geom_line()
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2011.png)

如果我们在加入一个geom_smooth()：

```
ggplot(Oxboys, aes(x = age, y = height, group = Subject)) + geom_line() + geom_smooth()
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2012.png)

这是因为geom_smooth()继承了来自于ggplot()的设置。

这里要用到一个重要的函数：stat_unique，作用在于删除数据集中的重复行，默认的几何形状是geom_point()。

```
ggplot(mpg, aes(x = class, y = hwy)) + geom_point()
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2013.png)

上图可以被考虑存在着一些重叠，为了进一步的确认，可以使用alpha来进行查看：

```
ggplot(mpg, aes(x = class, y = hwy)) + geom_point(alpha = 0.3)
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2014.png)

可以发现确实存在着不少的重叠。

接着来使用stat_unique()：

```
ggplot(mpg, aes(x = class, y = hwy)) + stat_unique(alpha = 0.3)
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2015.png)

或者也可以这样做：

```
ggplot(mpg, aes(x = class, y = hwy)) + geom_point(alpha = 0.3, stat = "unique")
```

接下来的一个重点是stat_summary()统计数据：

```
ggplot(mpg, aes(x = class, y = hwy)) + stat_summary()
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2016.png)

我们来添加一个geom_point()和添加一些参数：

```
ggplot(mpg, aes(x = class, y = hwy)) + geom_point(alpha = 0.3, position = "jitter") +
  stat_summary(fun = mean)
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2017.png)

修改一下stat_summary()的颜色来更加明显地查看：

```
ggplot(mpg, aes(x = class, y = hwy)) + geom_point(alpha = 0.3, position = "jitter") +
  stat_summary(fun = mean, color = "red", size = 0.5)
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2018.png)

或者我们可以这样绘制：

```
ggplot(mpg, aes(x = class, y = hwy)) +
  geom_point(alpha = 0.3, position = "jitter") +
  geom_point(stat = "summary", fun = mean, color = "red", size = 4)
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2019.png)

这是一些更多的内容：

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2020.png)

## Computed Aesthetics

当stat performs a transformation的时候，一个new variables被创建了出来。

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2021.png)

```
ggplot(mpg, aes(displ)) + geom_histogram(aes(y = ..count..))
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2022.png)

## Distributions and Plot

Distribution指的是数据集中各个数值的分布模式。在R语言中，我们可以使用不同的函数来绘制分布图，常见的函数包括：

- `hist()`：绘制直方图
- `density()`：绘制密度图
- `boxplot()`：绘制箱线图
- `qqnorm()`和`qqline()`：绘制Q-Q图
- `ecdf()`：绘制经验分布函数图

下面是一些例子：

```
library(ggplot2)

# 绘制直方图
ggplot(mpg, aes(x = hwy)) + geom_histogram()

# 绘制密度图
ggplot(mpg, aes(x = hwy)) + geom_density()

# 绘制箱线图
ggplot(mpg, aes(x = class, y = hwy)) + geom_boxplot()

# 绘制Q-Q图
qqnorm(mpg$hwy)
qqline(mpg$hwy)

# 绘制经验分布函数图
ggplot(mpg, aes(x = hwy)) + stat_ecdf()

```

以上是一些常见的绘制分布图的函数，你可以根据需要选择合适的函数来绘制你想要的分布图。

箱线图：

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2023.png)

Q-Q图：

```
qqnorm(mpg$hwy)
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2024.png)

```
qqline(mpg$hwy)
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2025.png)

经验分布图：

```
ggplot(mpg, aes(x = hwy)) + stat_ecdf()
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2026.png)

density图：

```
ggplot(mpg, aes(x = hwy)) + geom_density()
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2027.png)

## Voilin Plots

小提琴图是一种用于可视化数值变量分布情况的图表。它结合了箱线图和密度图的特点，可以显示出数据的分布情况、中位数、四分位数和异常值等信息。以下是在R中绘制小提琴图的代码示例：

```
# 导入ggplot2包
library(ggplot2)

# 绘制小提琴图
ggplot(mpg, aes(x = class, y = hwy)) +
  geom_violin()

```

在这个示例中，我们使用ggplot2包绘制了一个小提琴图，其中x轴为汽车的类型（class），y轴为公路英里数（hwy）。

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2028.png)

在加上geom_boxplot()：

```
ggplot(mpg, aes(x = class, y = hwy)) +
  geom_violin() + geom_boxplot()
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2029.png)

```
ggplot(mpg, aes(x = class, y = hwy)) +
  geom_violin(trim = T)
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2030.png)

```
ggplot(mpg, aes(x = class, y = hwy)) +
  geom_violin(trim = F)
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2031.png)

```
ggplot(mpg, aes(x = class, y = hwy)) +
  geom_violin(scale = "area")
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2032.png)

```
ggplot(mpg, aes(x = class, y = hwy)) +
  geom_violin(scale = "count")
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2033.png)

```
ggplot(mpg, aes(x = class, y = hwy)) +
  geom_violin(scale = "width")
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2034.png)

一个更加重要的是打印分位数：

```
ggplot(mpg, aes(x = class, y = hwy)) +
  geom_violin(draw_quantiles = c(0.25, 0.5, 0.75))
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2035.png)

还有就是加入class：

```
ggplot(mpg, aes(x = class, y = hwy)) +
  geom_violin(draw_quantiles = c(0.25, 0.5, 0.75), aes(fill = class))
```

![Untitled](4%20-%20Statistical%20transformations%20and%20Plotting%20Distr%20f976da9279874e7098dbfd60e79409d4/Untitled%2036.png)